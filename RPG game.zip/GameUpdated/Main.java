
import scenes.*;
import mainCharcter.*;
import UserInterface.UserInterface;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        Forest forest = new Forest();
        Context context = new Context();

        UserInterface ui = new UserInterface(context);
        ui.getThread().join();

        MainCharacter meen = MainCharacter.getCharacter(context, ui);
        meen.getThread().join();
    }
}