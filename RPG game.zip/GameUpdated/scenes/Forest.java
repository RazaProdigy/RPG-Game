package scenes;

import mainCharcter.Command;
import monsters.Wolves;
import weapon.FightLog;
import weapon.Log;
import weapon.PickLog;
import weapon.Weapon;


public class Forest extends Scenes implements State{

	Wolves wolves = new Wolves();
	Log l;
	PickLog pl = new PickLog(l);
	FightLog fl = new FightLog(l);
	
	

	public Forest(){
		super.weapon = new Log();
	}

	public void prev(Context context) {

		System.out.println("The player is in its rootstate.");
	}

	public void next(Context context) {
		context.setState(new Pathway());
	}

	public void printStatus() {
		System.out.println("in the forest");
	}

}