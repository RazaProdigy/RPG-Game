package scenes;

import mainCharcter.MainCharacter;
import mainCharcter.MoveControl;
import mainCharcter.MoveNorth;
import mainCharcter.MoveSouth;
import mainCharcter.Observer;
import mainCharcter.Subject;
import weapon.Command;
import weapon.PickWeapon;
import weapon.Smash;
import weapon.Swing;
import weapon.Throw;
import weapon.Weapon;
import weapon.WeaponControl;

public abstract class Scenes implements Observer {

    Weapon weapon;

    public void update(Subject s) {
            MainCharacter player = (MainCharacter) s;

            MoveNorth north = new MoveNorth();
			MoveSouth south = new MoveSouth();
						
			PickWeapon pick = new PickWeapon(weapon);
			Command[] pickWeapon = {pick};

			Smash smash = new Smash(weapon);
			Swing swing = new Swing(weapon);
			Throw thr = new Throw(weapon);
			
			Command[] commandMove= {north, south}; 
			MoveControl moveControl = new MoveControl(commandMove);
			moveControl.moveDirection(commandInd);
			
			Command[] commandWeapon = {smash, swing, thr};
			WeaponControl weaponControl = new WeaponControl(commandWeapon);

			weaponControl.useWeapon(commandInd);

			inCommand = false;  
    }
    

}