package scenes;

public class Pathway implements State {

    @Override
    public void next(Context c) {

    }

    @Override
    public void prev(Context c) {

    }

    @Override
    public void printStatus() {

    }
    
}