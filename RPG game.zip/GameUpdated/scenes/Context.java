package scenes;
import weapon.FightLog;
import weapon.Log;
import weapon.PickLog;


public class Context {
	
    
    private State scene = new Forest();
    int steps;
    
    public void previousState() {
    scene.prev(this);
    }

    public void nextState() {
    scene.next(this);
    }

    public void printStatus() {
    scene.printStatus();
    }

    public void setState(State state) {
    this.scene = state;
    }
}