package monsters;

import mainCharcter.*;

public class Wolves implements Observer, Runnable{
    
    Thread t ;
    
public Wolves(){
        t = new Thread(this);
        t.start();
}
        
@Override
    public void update(Subject s) {
    

   }


    public void run(){



        
    }
    
}