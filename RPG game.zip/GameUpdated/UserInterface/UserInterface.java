package UserInterface;

import mainCharcter.*;
import scenes.Context;

import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface implements Runnable, Subject, Observer {
	
	Thread t;
	ArrayList<Observer> player;
	Scanner input = new Scanner(System.in);
	int option;
	static Context context;
	
	public UserInterface(Context c) {
		player = new ArrayList();
		
		t = new Thread(this, "UI");
		t.start();
		context = c;
	}
	
	@Override
	public void update(Subject s) {
		MainCharacter player = (MainCharacter) s;	
	}

	@Override
	public synchronized void notifyObservers() {
		for(Observer obs : player)
			
			obs.update(this);
	}

	@Override
	public void addObserver(Observer o) {
		player.add(o);
	}

	@Override
	public void removeObserver(Observer o) {
		// TODO Auto-generated method stub	
	}
	
	public synchronized int getCommand() {
		return option;
	}

	@Override
	public void run() {
		while(true) {
			
			context.printStatus();
			System.out.println("Enter a command. Use ? to view all commands");
			option = input.nextInt();
			
			notifyObservers(); 
		}
		
	}
	
	
	public Thread getThread() {
		return t;
	}
	
	

}
