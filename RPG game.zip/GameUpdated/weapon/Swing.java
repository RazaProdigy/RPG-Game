package weapon;

public class Swing implements Command {
		Weapon weapon;
		
		public Swing(Weapon w){
			weapon = w;
		}
		
		public void execute() {
			weapon.swingWeapon();
		}
	
	
	

}
