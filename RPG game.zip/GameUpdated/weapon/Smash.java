package weapon;

public class Smash implements Command{
	Weapon weapon;
	
	public Smash(Weapon w) {
		weapon = w;
	}

	public void execute() {
		weapon.smashHead();
	}
}
