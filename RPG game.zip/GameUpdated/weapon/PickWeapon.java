package weapon;

public class PickWeapon implements Command{

        Weapon weapon;
		
		public PickWeapon(Weapon w){
			weapon = w;
		}
		
		public void execute() {
			weapon.swingWeapon();
		}

    }
    
