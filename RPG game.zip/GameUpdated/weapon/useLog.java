package weapon;
import commandPalette.*;

public class useLog implements Command {

    Log l;
    useLog(log l){
        this.l = l;
    }

    public void execute(){
        
    }




}