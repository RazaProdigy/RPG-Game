package weapon;

import weapon.Weapon;

public class Rod implements Weapon{

	@Override
	public void throwWeapon() {
		System.out.println("Throwing rod");
		System.out.println("Rod hit the enemy");
	}

	@Override
	public void swingWeapon() {
		System.out.println("Swinging stone while in the hand");
		
	}

	@Override
	public void smashHead() {
		System.out.println("Smashing head with stone");
		
	}

	public void pickWeapon(){
		System.out.println("you picked up the rod");
	}
}
