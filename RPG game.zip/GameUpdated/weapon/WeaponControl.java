package weapon;

public class WeaponControl {
	Command[] slots;
	
	public WeaponControl(Command[] slots) {
		this.slots = slots;
	}
	
	public void useWeapon(int index) {
		slots[index].execute();
	}
	

}
