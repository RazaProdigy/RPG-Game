package weapon;

public interface Weapon {

	public void pickWeapon();
	public void throwWeapon();
	public void swingWeapon();
	public void smashHead(); 
}
