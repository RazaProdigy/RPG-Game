package weapon;

public interface Command {

	void execute();
}
