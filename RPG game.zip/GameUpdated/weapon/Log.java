package weapon;

import weapon.Weapon;

public class Log implements Weapon{

	@Override
	public void throwWeapon() {
		System.out.println("Throwing log");
		System.out.println("Log hit the enemy");
	}

	@Override
	public void swingWeapon() {
		System.out.println("Swinging log while in the hand");
	}

	@Override
	public void smashHead() {
		System.out.println("Smashing head with log");
	}

	public void pickWeapon(){
		System.out.println("you picked up the log");
	}
	
	public void attackWeapon() {
		
		System.out.println("you strike with the log");
	}

}
