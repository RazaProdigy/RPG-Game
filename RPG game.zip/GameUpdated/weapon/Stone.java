package weapon;

public class Stone implements Weapon{

	@Override 
	public void throwWeapon() {
		System.out.println("Throwing stone");
		System.out.println("Stone hit the enemy");		
	}

	@Override
	public void swingWeapon() {
		System.out.println("Swinging stone while in the hand");
	}

	@Override
	public void smashHead() {
		System.out.println("Smashing head with stone");
	}

	public void pickWeapon(){
		System.out.println("you picked up the stone");
	}
}
