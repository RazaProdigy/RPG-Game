package weapon;

public class Hands implements Weapon {
	
	@Override
	public void throwWeapon() {
		System.out.println("Nothing to throw");
	
		
		
	}

	@Override
	public void swingWeapon() {
		System.out.println("Throwing a punch");
		
	}

	@Override
	public void smashHead() {
		System.out.println("Smashing head with hands");
		
	}

}
