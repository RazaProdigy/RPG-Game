package weapon;

public class Throw implements Command{
	Weapon weapon;
	
	public Throw(Weapon w) {
		weapon = w;
	}
	
	public void execute() {
		weapon.throwWeapon(); 
	}

}
