package weapon;

public class PickLog implements Command {

	Log l;
	public PickLog(Log l){
		this.l = l;
		
	}
	
	public void execute() {
		
		l.pickWeapon();
	}
	
	
	
	
}
