package weapon;

public class FightLog implements Command {
	
	Log l;
	public FightLog(Log l){
		this.l = l;
		
	}
	
	public void execute() {
		
		l.attackWeapon();
	}
	

}
