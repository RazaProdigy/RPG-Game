package weapon;

public class WeaponReciever {
	
	

}
