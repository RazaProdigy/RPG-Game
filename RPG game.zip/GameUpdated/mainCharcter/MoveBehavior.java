package mainCharcter;

public interface MoveBehavior {
	
	public void move();

}
