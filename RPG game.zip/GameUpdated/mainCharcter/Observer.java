package mainCharcter;

public interface Observer {
	
	public void update(Subject s);
}
