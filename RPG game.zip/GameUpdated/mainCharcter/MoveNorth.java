package mainCharcter;

import weapon.Command;

public class MoveNorth implements Command {

    
    public void execute() {
        
        System.out.println("You fell into a river and died");
    }
    
}