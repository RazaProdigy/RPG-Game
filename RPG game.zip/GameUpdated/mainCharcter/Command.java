package mainCharcter;

public interface Command {

	public void execute();
	
}
