package mainCharcter;

public class ControlPanel {
	Command [] slots;
	
	public ControlPanel(Command [] slots) {
		this.slots = slots;
	}
	
	public void performAction(int index){
		slots[index].execute();
	}
}
