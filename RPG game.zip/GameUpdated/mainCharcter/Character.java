package mainCharcter;

import java.util.ArrayList;

import javax.naming.Context;

import context.*;
import weapon.Weapon;

public class Character implements Runnable, Subject, Observer{
	
	
	Weapon weaponB;
	
	private static Character instance;
	ArrayList<Observer> observers;

	Context context;
	
	Thread t;

	private Character(Context c) {
		observers = new ArrayList();
		t = new Thread();
		context = c;
	}

	public static synchronized Character getCharacter(Context cont) {
		if (instance == null){
			new Character(cont);
			
		}
		return instance;
	}
	
	@Override
	public void notifyObservers() {
		for(Observer obs:observers)
			obs.update(this);
	}

	@Override
	public void addObserver(Observer o) {
		observers.add(o);
		
	}

	@Override
	public void removeObserver(Observer o) {

		int i = observers.indexOf(o);
		if(i > -1) 
			observers.remove(i);
		
	}

	@Override
	public void run() {
	
	}

	@Override
	public void update(Subject s) {
	
		
	}
	
	

}
