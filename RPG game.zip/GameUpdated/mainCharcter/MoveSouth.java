package mainCharcter;

import weapon.Command;

public class MoveSouth implements Command {

    public void execute() {
        
        System.out.println("You moved south");

    }
    
}