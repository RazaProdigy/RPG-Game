package mainCharcter;

import weapon.Command;
import java.util.ArrayList;

public class MoveControl {
    
    Command [] slots;

public MoveControl(Command [] slots) {
    this.slots = slots;
}

public void moveDirection(int index){
    slots[index].execute();
}

}