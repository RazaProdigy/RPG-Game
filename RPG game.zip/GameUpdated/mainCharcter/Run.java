package mainCharcter;

public class Run implements MoveBehavior{

	@Override
	public void move() {
		System.out.println("Running!");		
	}
	

}
