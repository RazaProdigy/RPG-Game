package mainCharcter;

//import context.*;
import monsters.Wolves;
import weapon.*;
import UserInterface.UserInterface;
import scenes.*;

import java.util.ArrayList;

public class MainCharacter implements Runnable, Subject, Observer{

	Weapon weapon = new Hands();
	public int commandInd;
	boolean inCommand;
	ControlPanel cp;

	

	private static MainCharacter instance;
	ArrayList<Wolves> observers;
	UserInterface uiObserver; 

	static Context context;

	Thread t;

	ArrayList<Command> commands;

	private MainCharacter(Context c, Subject s) {
		observers = new ArrayList();
		t = new Thread(this);
		t.start();
		context = c;
		s.addObserver(this);
	}

	public static synchronized MainCharacter getCharacter(scenes.Context context2, Subject s) {
		if (instance == null){
			new MainCharacter(context, s);
		}
		return instance;
	}

	@Override
	public void notifyObservers() {
		for(Observer obs:observers)
			obs.update(this);
	}

	@Override
	public void addObserver(Observer o) {
		observers.add((Wolves) o);

	}

	@Override
	public void removeObserver(Observer o) {

		int i = observers.indexOf(o);
		if(i > -1) 
			observers.remove(i);

	}

	@Override
	public void run() {

		while(true) {
			//if(commandInd == 1) {
				context.printStatus();
				
				
		//	}
			
			
		}



	}

	@Override
	public void update(Subject s) {

		UserInterface ui = (UserInterface)s;
		commandInd = ui.getCommand();


	}

	public synchronized int getCommand() {
		return commandInd;
	}

	public Thread getThread() {
		return t;
	}
}
