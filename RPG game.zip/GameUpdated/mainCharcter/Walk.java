package mainCharcter;

public class Walk implements MoveBehavior{

    @Override
    public void move() {
        System.out.println("Walking");
    }
}